package com.threads2video

import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.webkit.WebViewAssetLoader
import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStream

class MainActivity : ComponentActivity() {

    private lateinit var web: WebView
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var saveStream: OutputStream? = null
    private var saveUri: Uri? = null

    private val picker = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val cb = fileCallback
        fileCallback = null
        cb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res.resultCode, res.data))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web = WebView(this)
        setContentView(web)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false
            allowContentAccess = true
            cacheMode = WebSettings.LOAD_DEFAULT
        }

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                return loader.shouldInterceptRequest(request.url)
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView,
                callback: ValueCallback<Array<Uri>>,
                params: FileChooserParams
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                return try {
                    picker.launch(params.createIntent())
                    true
                } catch (e: Exception) {
                    fileCallback = null
                    false
                }
            }
        }

        web.addJavascriptInterface(Bridge(), "Android")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("(window.__back ? window.__back() : true)") { r ->
                    if (r == "true") finish()
                }
            }
        })

        web.loadUrl("https://appassets.androidplatform.net/assets/www/index.html")
    }

    override fun onResume() {
        super.onResume()
        deliverVoices()
        deliverThreads()
    }

    /** Đẩy kết quả quét Threads vào trang chính. */
    private fun deliverThreads() {
        val j = ThreadsInbox.json
        if (j.isEmpty()) return
        val k = ThreadsInbox.kind
        ThreadsInbox.json = ""
        js("window.__thr && window.__thr(" + JSONObject.quote(k) + "," + JSONObject.quote(j) + ")")
    }

    private fun js(code: String) {
        runOnUiThread { web.evaluateJavascript(code, null) }
    }

    /** Đẩy các file giọng tải từ Studio vào trang chính, lần lượt từng file. */
    private fun deliverVoices() {
        val list = VoiceInbox.files.toList()
        if (list.isEmpty()) return
        VoiceInbox.files.clear()
        Thread {
            for (f in list) {
                try {
                    val bytes = f.readBytes()
                    js("window.__vcBegin(" + JSONObject.quote(f.name) + ")")
                    val ch = 600000
                    var off = 0
                    while (off < bytes.size) {
                        val end = minOf(off + ch, bytes.size)
                        val b64 = Base64.encodeToString(bytes, off, end - off, Base64.NO_WRAP)
                        js("window.__vcChunk('" + b64 + "')")
                        off = end
                    }
                    js("window.__vcEnd()")
                } catch (_: Exception) {
                } finally {
                    f.delete()
                }
            }
        }.start()
    }

    override fun onDestroy() {
        try { saveStream?.close() } catch (_: Exception) {}
        web.destroy()
        super.onDestroy()
    }

    inner class Bridge {
        @JavascriptInterface
        fun beginSave(name: String, mime: String): Boolean {
            return try {
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, name)
                    put(MediaStore.Video.Media.MIME_TYPE, mime)
                    put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/Threads2Video")
                    put(MediaStore.Video.Media.IS_PENDING, 1)
                }
                val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                if (uri == null) {
                    false
                } else {
                    saveUri = uri
                    saveStream = contentResolver.openOutputStream(uri)
                    saveStream != null
                }
            } catch (e: Exception) {
                false
            }
        }

        @JavascriptInterface
        fun writeChunk(b64: String): Boolean {
            return try {
                saveStream?.write(Base64.decode(b64, Base64.DEFAULT))
                true
            } catch (e: Exception) {
                false
            }
        }

        @JavascriptInterface
        fun endSave(): String {
            val uri = saveUri ?: return ""
            try {
                saveStream?.flush()
                saveStream?.close()
                val values = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
                contentResolver.update(uri, values, null, null)
            } catch (_: Exception) {}
            saveStream = null
            return uri.toString()
        }

        @JavascriptInterface
        fun share(uriStr: String, mime: String) {
            runOnUiThread {
                try {
                    val i = Intent(Intent.ACTION_SEND).apply {
                        type = mime
                        putExtra(Intent.EXTRA_STREAM, Uri.parse(uriStr))
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    startActivity(Intent.createChooser(i, "Chia sẻ video"))
                } catch (_: Exception) {
                    Toast.makeText(this@MainActivity, "Không mở được trình chia sẻ", Toast.LENGTH_SHORT).show()
                }
            }
        }

        @JavascriptInterface
        fun openStudio(scriptsJson: String) {
            runOnUiThread {
                val arr = try { JSONArray(scriptsJson) } catch (e: Exception) { JSONArray() }
                val list = Array(arr.length()) { i -> arr.optString(i) }
                val i = Intent(this@MainActivity, StudioActivity::class.java)
                i.putExtra("scripts", list)
                startActivity(i)
            }
        }

        @JavascriptInterface
        fun openThreads(mode: String, url: String, n: Int) {
            runOnUiThread {
                val i = Intent(this@MainActivity, ThreadsActivity::class.java)
                i.putExtra("mode", mode)
                i.putExtra("url", url)
                i.putExtra("n", n)
                startActivity(i)
            }
        }

        @JavascriptInterface
        fun toast(msg: String) {
            runOnUiThread { Toast.makeText(this@MainActivity, msg, Toast.LENGTH_SHORT).show() }
        }

        @JavascriptInterface
        fun exit() {
            runOnUiThread { finish() }
        }
    }
}
