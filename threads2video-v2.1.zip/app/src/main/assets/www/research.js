'use strict';
/* Research chủ đề Threads: tìm bài hay, cào link, tự điền nội dung */
(function () {
  const $ = id => document.getElementById(id);
  const fmt = n => n >= 1e6 ? (n / 1e6).toFixed(1).replace('.', ',') + 'M' : n >= 1e3 ? (n / 1e3).toFixed(1).replace('.', ',') + 'K' : String(n);
  const nCmt = () => +$('rsN').value || 7;
  const open = (mode, url) => {
    if (!window.Android || !Android.openThreads) { toast('Tính năng này chỉ chạy trong app Android'); return; }
    Android.openThreads(mode, url, nCmt());
  };

  ['tâm sự công sở', 'hài hước', 'tình yêu', 'gia đình', 'bạn bè'].forEach(t => {
    const b = document.createElement('button');
    b.className = 'ghost'; b.textContent = t;
    b.onclick = () => { $('rsTopic').value = t; };
    $('rsChips').appendChild(b);
  });

  $('btnRs').onclick = () => {
    const t = $('rsTopic').value.trim();
    if (!t) { toast('Nhập chủ đề trước'); return; }
    open('search', 'https://www.threads.com/search?q=' + encodeURIComponent(t) + '&serp_type=default');
  };
  $('btnRsLink').onclick = () => {
    const u = $('rsLink').value.trim();
    if (!/^https?:\/\/(www\.)?threads\.(com|net)\/.+\/post\//.test(u)) { toast('Link phải có dạng threads.com/@ten/post/…'); return; }
    open('post', u);
  };

  function render(list) {
    const box = $('rsList'); box.innerHTML = '';
    if (!list.length) { toast('Không tìm thấy bài phù hợp'); return; }
    list.forEach((p, i) => {
      const d = document.createElement('div'); d.className = 'vl';
      const n = document.createElement('span'); n.className = 'n'; n.textContent = i + 1;
      const t = document.createElement('span'); t.className = 't';
      t.textContent = p.user + ' · ' + fmt(p.likes) + ' tim · ' + (p.text.length > 90 ? p.text.slice(0, 90) + '…' : p.text);
      const b = document.createElement('button'); b.className = 'ghost'; b.textContent = 'Dùng';
      b.onclick = () => open('post', p.url);
      d.appendChild(n); d.appendChild(t); d.appendChild(b); box.appendChild(d);
    });
    toast('Đã xếp ' + list.length + ' bài theo số tim');
  }

  function fill(d) {
    if (!d.post) { toast('Không lấy được bài viết'); return; }
    const cms = d.comments || [];
    $('pUser').value = d.post.user;
    $('pText').value = d.post.text;
    $('cText').value = cms.map(c => c.user + (c.likes ? ' | ' + fmt(c.likes) : '') + '\n' + c.text).join('\n\n');
    ['pText', 'cText'].forEach(id => $(id).dispatchEvent(new Event('input')));
    $('pUser').scrollIntoView();
    toast('Đã cào bài của ' + d.post.user + ' và ' + cms.length + ' bình luận (nhiều tim nhất)');
  }

  window.__thr = (kind, json) => {
    let d;
    try { d = JSON.parse(json); } catch (e) { toast('Dữ liệu từ Threads không đọc được'); return; }
    if (kind === 'search') render(d.list || []); else fill(d);
  };
})();
